# bot.py
import json
import os
import random
from uuid import uuid4
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
)
from telegram.ext import (
    Updater, CommandHandler, MessageHandler, Filters,
    CallbackQueryHandler, CallbackContext
)

BOT_TOKEN = "8303973487:AAGTsnjYNNCKIX9pfb8TwFOteoomtDKvEt0"
DATA_FILE = "rooms.json"

# --------------------------- STORAGE ---------------------------

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump({}, f)


def load():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


rooms = load()


# --------------------------- MENU ---------------------------

def main_menu(user_id):
    kb = [
        [InlineKeyboardButton("🎄 Создать комнату", callback_data="menu_create")]
    ]
    return InlineKeyboardMarkup(kb)


def admin_menu(room_id):
    kb = [
        [InlineKeyboardButton("🎲 Запустить игру", callback_data=f"draw_{room_id}")],
        [InlineKeyboardButton("👥 Список участников", callback_data=f"list_{room_id}")],
        [InlineKeyboardButton("❌ Удалить комнату", callback_data=f"delete_{room_id}")]
    ]
    return InlineKeyboardMarkup(kb)


def user_menu(room_id):
    kb = [
        [InlineKeyboardButton("🎁 Кому я дарю?", callback_data=f"myrecv_{room_id}")],
        [InlineKeyboardButton("🎄 Мой подарок", callback_data=f"mygift_{room_id}")],
        [InlineKeyboardButton("✏ Изменить подарок", callback_data=f"chg_{room_id}")]
    ]
    return InlineKeyboardMarkup(kb)


# --------------------------- START ---------------------------

def cmd_start(update: Update, context: CallbackContext):
    msg = update.message

    if msg.text.startswith("/start join_"):
        return handle_join_link(update, context)

    msg.reply_text(
        "🎅 <b>Добро пожаловать в Тайного Санту!</b>\n\n"
        "Создай комнату, пригласи друзей, запусти жеребьёвку — и я всем тайно разошлю, кому кого дарить 🎁",
        reply_markup=main_menu(msg.from_user.id),
        parse_mode=ParseMode.HTML
    )


# --------------------------- CREATE ROOM ---------------------------

def cb_create_room(update: Update, context: CallbackContext):
    q = update.callback_query
    q.answer()

    q.message.reply_text("Введите название комнаты:")
    context.user_data["create_step"] = "title"


def message_create_room(update: Update, context: CallbackContext):
    if context.user_data.get("create_step") != "title":
        return

    title = update.message.text
    user_id = update.message.from_user.id
    room_id = uuid4().hex[:8]

    rooms[room_id] = {
        "title": title,
        "admin": user_id,
        "participants": [],
        "assignments": {}
    }
    save(rooms)

    join_link = f"https://t.me/{context.bot.username}?start=join_{room_id}"

    update.message.reply_text(
        f"✨ Комната <b>{title}</b> создана!\n\n"
        f"🔗 Перешли ссылку друзьям:\n{join_link}",
        parse_mode=ParseMode.HTML
    )

    update.message.reply_text(
        "⚙️ Админ-панель:",
        reply_markup=admin_menu(room_id),
        parse_mode=ParseMode.HTML
    )

    context.user_data.pop("create_step", None)


# --------------------------- JOIN LINK ---------------------------

def handle_join_link(update: Update, context: CallbackContext):
    msg = update.message
    user = msg.from_user
    room_id = msg.text.split("join_")[1]

    room = rooms.get(room_id)
    if not room:
        return msg.reply_text("Комната не найдена.")

    context.user_data["join_room"] = room_id
    context.user_data["step"] = "name"

    msg.reply_text(
        f"🎄 Ты присоединяешься к комнате <b>{room['title']}</b>!\n\n"
        "Как тебя подписать?",
        parse_mode=ParseMode.HTML
    )


# --------------------------- JOIN PROCESS ---------------------------

def private_flow(update: Update, context: CallbackContext):
    user = update.message.from_user
    text = update.message.text

    # Creating room
    if context.user_data.get("create_step") == "title":
        return message_create_room(update, context)

    # Joining room
    if "join_room" not in context.user_data:
        return update.message.reply_text("Используй /start")

    room_id = context.user_data["join_room"]
    room = rooms.get(room_id)
    step = context.user_data.get("step")

    # Step 1 — name
    if step == "name":
        context.user_data["name"] = text
        context.user_data["step"] = "gift"
        return update.message.reply_text("🎁 Теперь напиши, какой подарок ты хочешь?")

    # Step 2 — gift
    if step == "gift":
        name = context.user_data["name"]
        gift = text

        room["participants"].append({
            "user_id": user.id,
            "name": name,
            "gift": gift
        })
        save(rooms)

        context.user_data.clear()

        notify_all(room_id, f"✨ <b>{name}</b> присоединился!")

        update.message.reply_text(
            "🎄 Ты в игре! Вот твоё меню:",
            reply_markup=user_menu(room_id),
            parse_mode=ParseMode.HTML
        )


# --------------------------- NOTIFY PARTICIPANTS ---------------------------

def notify_all(room_id, text):
    room = rooms.get(room_id)
    if not room:
        return

    plist = "\n".join(f"• {p['name']}" for p in room["participants"])

    full = f"{text}\n\n👥 <b>Участники:</b>\n{plist}"

    for p in room["participants"]:
        try:
            updater.bot.send_message(p["user_id"], full, parse_mode=ParseMode.HTML)
        except:
            pass


# --------------------------- ADMIN: LIST ---------------------------

def cb_list(update, context):
    q = update.callback_query
    q.answer()

    room_id = q.data.split("_")[1]
    room = rooms.get(room_id)

    plist = "\n".join(f"• {p['name']}" for p in room["participants"])

    q.message.reply_text(
        f"👥 <b>Участники ({len(room['participants'])}):</b>\n{plist}",
        parse_mode=ParseMode.HTML
    )


# --------------------------- GAME DRAW ---------------------------

def cb_draw(update, context):
    q = update.callback_query
    q.answer()

    room_id = q.data.split("_")[1]
    room = rooms.get(room_id)
    parts = room["participants"]

    if len(parts) < 2:
        return q.message.reply_text("Нужны минимум 2 участника!")

    idx = list(range(len(parts)))
    perm = idx[:]

    while True:
        random.shuffle(perm)
        if all(perm[i] != idx[i] for i in idx):
            break

    assignments = {}

    for giver_idx, recv_idx in zip(idx, perm):
        giver = parts[giver_idx]
        recv = parts[recv_idx]

        assignments[giver["user_id"]] = recv["user_id"]

        context.bot.send_message(
            giver["user_id"],
            f"🎅 <b>Жеребьёвка!</b>\n\n"
            f"Ты даришь подарочек для <b>{recv['name']}</b>\n"
            f"Его пожелание: <i>{recv['gift']}</i>",
            parse_mode=ParseMode.HTML
        )

    room["assignments"] = assignments
    save(rooms)

    q.message.reply_text("🎄 Игра запущена! Все получили своих одариваемых.")


# --------------------------- DELETE ROOM ---------------------------

def cb_delete(update, context):
    q = update.callback_query
    q.answer()

    room_id = q.data.split("_")[1]
    room = rooms.get(room_id)

    if not room:
        return q.message.reply_text("Комната уже удалена.")

    for p in room["participants"]:
        try:
            context.bot.send_message(
                p["user_id"],
                f"Комната <b>{room['title']}</b> удалена.",
                parse_mode=ParseMode.HTML
            )
        except:
            pass

    del rooms[room_id]
    save(rooms)

    q.message.reply_text("Удалено.")


# --------------------------- USER: WHO I GOT ---------------------------

def cb_myrecv(update, context):
    q = update.callback_query
    q.answer()

    room_id = q.data.split("_")[1]
    room = rooms.get(room_id)

    uid = q.from_user.id

    recv_id = room["assignments"].get(uid)
    if not recv_id:
        return q.message.reply_text("Жеребьёвка ещё не запускалась!")

    recv = next(p for p in room["participants"] if p["user_id"] == recv_id)

    q.message.reply_text(
        f"🎁 Ты даришь для <b>{recv['name']}</b>\n"
        f"Он хочет: <i>{recv['gift']}</i>",
        parse_mode=ParseMode.HTML
    )


# --------------------------- USER: MY GIFT ---------------------------

def cb_mygift(update, context):
    q = update.callback_query
    q.answer()

    room_id = q.data.split("_")[1]
    room = rooms.get(room_id)
    uid = q.from_user.id

    user = next((p for p in room["participants"] if p["user_id"] == uid), None)

    q.message.reply_text(
        f"🎄 Твой подарок: <i>{user['gift']}</i>",
        parse_mode=ParseMode.HTML
    )


# --------------------------- USER: CHANGE GIFT ---------------------------

def cb_change(update, context):
    q = update.callback_query
    q.answer()

    room_id = q.data.split("_")[1]
    context.user_data["chg_room"] = room_id
    context.user_data["chg"] = True

    q.message.reply_text("Напиши новый подарок:")


def message_change_gift(update, context):
    if not context.user_data.get("chg"):
        return

    room_id = context.user_data["chg_room"]
    room = rooms.get(room_id)
    uid = update.message.from_user.id
    newgift = update.message.text

    for p in room["participants"]:
        if p["user_id"] == uid:
            p["gift"] = newgift

    save(rooms)

    update.message.reply_text(
        "🎁 Подарок обновлён!",
        reply_markup=user_menu(room_id),
        parse_mode=ParseMode.HTML
    )

    context.user_data.clear()


# --------------------------- HANDLERS ---------------------------

def main():
    global updater
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", cmd_start))

    # Create room
    dp.add_handler(CallbackQueryHandler(cb_create_room, pattern="menu_create"))

    # Admin
    dp.add_handler(CallbackQueryHandler(cb_list, pattern="list_"))
    dp.add_handler(CallbackQueryHandler(cb_draw, pattern="draw_"))
    dp.add_handler(CallbackQueryHandler(cb_delete, pattern="delete_"))

    # User buttons
    dp.add_handler(CallbackQueryHandler(cb_myrecv, pattern="myrecv_"))
    dp.add_handler(CallbackQueryHandler(cb_mygift, pattern="mygift_"))
    dp.add_handler(CallbackQueryHandler(cb_change, pattern="chg_"))

    # Join link
    dp.add_handler(MessageHandler(Filters.regex("^/start join_"), handle_join_link))

    # Private flows
    dp.add_handler(MessageHandler(Filters.private & Filters.text, private_flow))
    dp.add_handler(MessageHandler(Filters.private & Filters.text, message_change_gift))

    updater.start_polling()
    updater.idle()


if __name__ == "__main__":
    main()